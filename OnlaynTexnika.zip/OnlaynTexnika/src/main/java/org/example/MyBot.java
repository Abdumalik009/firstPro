package org.example;

import org.example.service.impl.UserServiceImpl;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.groupadministration.GetChatMember;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.send.SendPhoto;
import org.telegram.telegrambots.meta.api.objects.InputFile;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.api.objects.chatmember.ChatMember;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class MyBot extends TelegramLongPollingBot {
    public MyBot(String botToken) {
        super(botToken);
    }
    public static UserServiceImpl userService = new UserServiceImpl();

    @Override
    public void onUpdateReceived(Update update) {
        Long chatId = update.getMessage().getChatId();
        String text = update.getMessage().getText();
        if (update.hasMessage() && update.getMessage().hasText()) {


            if (text.equals("/start")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("Telefon raqam yuborish");
                uz.setRequestContact(true);

                    row2.add(uz);
                    rowList.add(row2);
                    markup.setKeyboard(rowList);
                    markup.setResizeKeyboard(true);
                    SendMessage message = new SendMessage();
                    message.setText("Assalomu alaykum "+update.getMessage().getFrom().getFirstName()+" \n"+
                            "Ro'yhatdan utish uchun telefon raqamingizni  kriting");
                    message.setChatId(chatId);
                    message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }


            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFUzbek tili")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();

                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardRow row4 = new KeyboardRow();
                KeyboardRow row5 = new KeyboardRow();
                KeyboardRow row6 = new KeyboardRow();
                KeyboardRow row7 = new KeyboardRow();
                KeyboardRow row8 = new KeyboardRow();
                KeyboardRow row9 = new KeyboardRow();
                KeyboardRow row10 = new KeyboardRow();
                KeyboardButton button1 = new KeyboardButton();
                button1.setText(" \uD83C\uDFDE Dizayn darslari ");
                KeyboardButton button2 = new KeyboardButton();
                button2.setText(" \uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBBDasturlash darslari ");
                KeyboardButton button3 = new KeyboardButton();
                button3.setText("\uD83D\uDCF1 SMM");
                KeyboardButton button4 = new KeyboardButton();
                button4.setText(" \uD83C\uDFC4\u200D♂\uFE0F Frilanserlik darslari");
                KeyboardButton button5 = new KeyboardButton();
                button5.setText("\uD83E\uDDEE Buxgalteriya kurslari");
                KeyboardButton button6 = new KeyboardButton();
                button6.setText(" \uD83D\uDCDD Kopirayting");
                KeyboardButton button7 = new KeyboardButton();
                button7.setText(" \uD83C\uDDFA\uD83C\uDDF8 Ingliz tili darslari");
                KeyboardButton button8 = new KeyboardButton();
                button8.setText("\uD83D\uDCD7 Office darslari");
                KeyboardButton uzsdfg = new KeyboardButton();
                uzsdfg.setText(" \uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67\u200D\uD83D\uDC66 Biz haqimizda");
                KeyboardButton button10 = new KeyboardButton();
                button10.setText(" \uD83D\uDCE9 Biz bilan bog'lanish");
                KeyboardButton button9 = new KeyboardButton();
                button9.setText("\uD83D\uDCCA Statistika");
                KeyboardButton button11 = new KeyboardButton();
                button11.setText("\uD83D\uDD19 Orqaga");


                row1.add(button1);
                row1.add(button2);
                row2.add(button3);
                row2.add(button4);
                row3.add(button5);
                row3.add(button6);
                row4.add(button7);
                row5.add(button8);
                row5.add(uzsdfg);
                row6.add(button9);
                row6.add(button10);
                row7.add(button11);




                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                rowList.add(row4);
                rowList.add(row5);
                rowList.add(row6);
                rowList.add(row7);
                rowList.add(row8);
                rowList.add(row9);
                rowList.add(row10);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi yo'nalishda ta'lim olmoqchisiz ");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDDF7\uD83C\uDDFARus tili")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardRow row4 = new KeyboardRow();
                KeyboardRow row5 = new KeyboardRow();
                KeyboardRow row6 = new KeyboardRow();
                KeyboardRow row7 = new KeyboardRow();
                KeyboardRow row8 = new KeyboardRow();
                KeyboardRow row9 = new KeyboardRow();
                KeyboardRow row10 = new KeyboardRow();
                KeyboardButton button1 = new KeyboardButton();
                button1.setText(" \uD83C\uDFDEУроки дизайна ");
                KeyboardButton button2 = new KeyboardButton();
                button2.setText(" \uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBBУроки программирования ");
                KeyboardButton button3 = new KeyboardButton();
                button3.setText("\uD83D\uDCF1 СММ ");
                KeyboardButton button4 = new KeyboardButton();
                button4.setText(" \uD83C\uDFC4\u200D♂\uFE0F Уроки фриланса");
                KeyboardButton button5 = new KeyboardButton();
                button5.setText("\uD83E\uDDEE Курсы бухгалтерского учета");
                KeyboardButton button6 = new KeyboardButton();
                button6.setText(" \uD83D\uDCDD Копировать");
                KeyboardButton button7 = new KeyboardButton();
                button7.setText(" \uD83C\uDDFA\uD83C\uDDF8 уроки английского");
                KeyboardButton button8 = new KeyboardButton();
                button8.setText("\uD83D\uDCD7 Офисные занятия");
                KeyboardButton uzsdfg = new KeyboardButton();
                uzsdfg.setText(" \uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67\u200D\uD83D\uDC66 о нас");
                KeyboardButton button10 = new KeyboardButton();
                button10.setText(" \uD83D\uDCE9 связаться с нами");
                KeyboardButton button9 = new KeyboardButton();
                button9.setText("\uD83D\uDCCA Статистика");
                KeyboardButton button11 = new KeyboardButton();
                button11.setText("\uD83D\uDD19 Назад");

                row1.add(button1);
                row1.add(button2);
                row2.add(button3);
                row2.add(button4);
                row3.add(button5);
                row3.add(button6);
                row4.add(button7);
                row5.add(button8);
                row5.add(uzsdfg);
                row6.add(button9);
                row6.add(button10);
                row7.add(button11);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                rowList.add(row4);
                rowList.add(row5);
                rowList.add(row6);
                rowList.add(row7);
                rowList.add(row8);
                rowList.add(row9);
                rowList.add(row10);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();

                message.setText("Qaysinida oqisiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDFDE Dizayn darslari")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("\uD83C\uDDFA\uD83C\uDDFF3D grafika");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("\uD83C\uDDFA\uD83C\uDDFFVideo Montaj");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("\uD83C\uDDFA\uD83C\uDDFFGrafik Montaj");


                row1.add(uz);
                row2.add(ru);
                row3.add(eng);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Mavzulardan birini tanlang");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDFDE Уроки дизайна")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("3D графика");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("Видеомонтаж");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Графический монтаж");


                row1.add(uz);
                row2.add(ru);
                row3.add(eng);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBBDasturlash darslari")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton damas = new KeyboardButton();
                damas.setText("\uD83C\uDDFA\uD83C\uDDFFFrontend");
                KeyboardButton spark = new KeyboardButton();
                spark.setText("\uD83C\uDDFA\uD83C\uDDFFBackend");
                KeyboardButton jentra = new KeyboardButton();
                jentra.setText("\uD83C\uDDFA\uD83C\uDDFFTelegram-Bot");

                row1.add(damas);
                row2.add(spark);
                row3.add(jentra);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Mavzulardan birini tanlang");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDC68\uD83C\uDFFB\u200D\uD83D\uDCBB Уроки программирования")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("Фронтенд");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("Баскенд");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Telegram-бот");


                row1.add(uz);
                row2.add(ru);
                row3.add(eng);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDCDD Kopirayting")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton atta = new KeyboardButton();
                atta.setText("\uD83C\uDDFA\uD83C\uDDFFKopirayting kursi (iPro)");
                KeyboardButton spark = new KeyboardButton();
                spark.setText("\uD83C\uDDFA\uD83C\uDDFFCo-Learning Academy");


                row1.add(atta);
                row2.add(spark);

                rowList.add(row1);
                rowList.add(row2);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Mavzulardan birini tanlang");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDCDDKoпирайтинг")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton damas = new KeyboardButton();
                damas.setText("Koпирайтинг курси (iPro)");
                KeyboardButton spark = new KeyboardButton();
                spark.setText("Co-Learning Academy");


                row1.add(damas);
                row2.add(spark);

                rowList.add(row1);
                rowList.add(row2);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDCF1 SMM")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("1-modul");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("2-modul");

                row1.add(uz);
                row2.add(ru);

                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDCF1 SMM")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("1-модуль ");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("2-модуль");

                row1.add(uz);
                row2.add(ru);

                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDFC4\u200D♂\uFE0F Frilanserlik darslari")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("UpWork'da karyera \uD83C\uDDFA\uD83C\uDDFF");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("Zafarbek Ibrohimov \uD83C\uDDFA\uD83C\uDDFF");

                row1.add(uz);
                row2.add(ru);

                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDFC4\u200D♂\uFE0F Уроки фриланса ")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("Карьера в UpWork \\uD83C\\uDDFA\\uD83C\\uDDFF");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("Зафарбек Ибрагимов \\uD83C\\uDDFA\\uD83C\\uDDFF");

                row1.add(uz);
                row2.add(ru);

                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("🧮 Buxgalteriya kurslari")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardButton uzed = new KeyboardButton();
                uzed.setText("1C dasturida ishlash \uD83C\uDDFA\uD83C\uDDFF");

                row1.add(uzed);

                rowList.add(row1);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals(" \uD83E\uDDEE Курсы бухгалтерского учета")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardButton uzed = new KeyboardButton();
                uzed.setText("Работа в программе 1С \uD83C\uDDFA\uD83C\uDDFF");

                row1.add(uzed);

                rowList.add(row1);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDF8 Ingliz tili darslari")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uzed = new KeyboardButton();
                uzed.setText("Easy English \uD83C\uDDFA\uD83C\uDDF8");
                KeyboardButton uzedn = new KeyboardButton();
                uzedn.setText("English cartoons with subtitle \uD83C\uDDFA\uD83C\uDDF8");
                KeyboardButton uzedl = new KeyboardButton();
                uzedl.setText("Prepuz \uD83C\uDDFA\uD83C\uDDF8");

                row1.add(uzed);
                row2.add(uzedn);
                row3.add(uzedl);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals(" \uD83C\uDDFA\uD83C\uDDF8 Уроки английского")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uzed = new KeyboardButton();
                uzed.setText("Easy English \\uD83C\\uDDFA\\uD83C\\uDDF8\"");
                KeyboardButton uzedi = new KeyboardButton();
                uzedi.setText("English cartoons with subtitle \uD83C\uDDFA\uD83C\uDDF8");
                KeyboardButton uzedo = new KeyboardButton();
                uzedo.setText("Prepuz \uD83C\uDDFA\uD83C\uDDF8");

                row1.add(uzed);
                row2.add(uzedi);
                row3.add(uzedo);



                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Выберите одну из тем");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83D\uDCE9 Biz bilan bog'lanish")) {}
            else if (update.getMessage().getText().equals(" \uD83D\uDCE9 Cвязаться с нами")) {}
            else if (update.getMessage().getText().equals(" \uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67\u200D\uD83D\uDC66 Biz haqimizda")) {}
            else if (update.getMessage().getText().equals(" \uD83D\uDC68\u200D\uD83D\uDC69\u200D\uD83D\uDC67\u200D\uD83D\uDC66 O нас")) {}
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFF3D grafika")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("3Ds Max (Inogamov 3D");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("Blender asoslari");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("ZBrush");

                row1.add(uz);
                row1.add(ru);
                row2.add(eng);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFVideo Montaj")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton oq = new KeyboardButton();
                oq.setText("Adobe After effects");
                KeyboardButton qora = new KeyboardButton();
                qora.setText("Adobe Premier Pro");

                row1.add(oq);
                row2.add(qora);
                rowList.add(row1);
                rowList.add(row2);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFGrafik Montaj")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton oq = new KeyboardButton();
                oq.setText("MockUp dizayn kursi");
                KeyboardButton qora = new KeyboardButton();
                qora.setText("Adobe Illustrator (Madina Mavlonova )");
                KeyboardButton saru = new KeyboardButton();
                saru.setText("Adobe Photoshop (Asror Iskandarov)");


                row1.add(oq);
                row2.add(qora);
                row3.add(saru);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi Kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("3D графика")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton Белый = new KeyboardButton();
                Белый.setText("3Ds Max (Inogamov 3D");
                KeyboardButton Черный = new KeyboardButton();
                Черный.setText("Blender asoslari");
                KeyboardButton malochni = new KeyboardButton();
                malochni.setText("ZBrush");


                row1.add(Белый);
                row1.add(Черный);
                row2.add(malochni);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("какой курс вы выберете");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("Видеомонтаж")) {

                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton oq = new KeyboardButton();
                oq.setText("Adobe After effects");
                KeyboardButton qora = new KeyboardButton();
                qora.setText("Adobe Premier Pro");

                row1.add(oq);
                row2.add(qora);

                rowList.add(row1);
                rowList.add(row2);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("какой курс вы выберете");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("Графический монтаж")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("Курс дизайна MockUp");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("Adobe Illustrator (Мадина Мавлонова)");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Adobe Photoshop (Асрор Искандаров)");

                row1.add(uz);
                row1.add(ru);
                row2.add(eng);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);

                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("какой курс вы выберете");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFFrontend")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("Frontend (Saud Abdulwahed )");
                KeyboardButton ru = new KeyboardButton();
                ru.setText("HTML va CSS");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("SASS (Javohir Group)");

                row1.add(uz);
                row1.add(ru);
                row2.add(eng);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }


            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFBackend")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton uz = new KeyboardButton();
                uz.setText("Phyton");
                KeyboardButton ru = new KeyboardButton();
                ru.setText(" C++");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Java");

                row1.add(uz);
                row1.add(ru);
                row2.add(eng);

                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFTelegram-Bot")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton ru = new KeyboardButton();
                ru.setText(" Telegram bot yaratish");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Phytonda telegram bot yaratish");


                row1.add(ru);
                row2.add(eng);

                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFTelegram-Bot")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton ru = new KeyboardButton();
                ru.setText(" Telegram bot yaratish");
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Phytonda telegram bot yaratish");


                row1.add(ru);
                row2.add(eng);

                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("\uD83C\uDDFA\uD83C\uDDFFKopirayting kursi (iPro)")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardButton eng = new KeyboardButton();
                eng.setText("1-Dars");


                row1.add(eng);

                rowList.add(row1);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }
            }
            else if (update.getMessage().getText().equals("Co-Learning Academy")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton eng = new KeyboardButton();
                eng.setText("1-Dars");
                KeyboardButton zr = new KeyboardButton();
                zr.setText("2-Dars");
                KeyboardButton kr = new KeyboardButton();
                kr.setText("3-Dars");


                row1.add(eng);
                row1.add(zr);
                row1.add(kr);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("Qaysi kursni tanlaysiz");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
            else if (update.getMessage().getText().equals("Фронтенд")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Фронтенд (Saud Abdulwahed )");
                KeyboardButton zr = new KeyboardButton();
                zr.setText("HTML va CSS");
                KeyboardButton kr = new KeyboardButton();
                kr.setText("SASS (Javohir Group)");


                row1.add(eng);
                row2.add(zr);
                row3.add(kr);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("какой курс вы выберете");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
            else if (update.getMessage().getText().equals("Баскенд")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardRow row3 = new KeyboardRow();
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Phyton");
                KeyboardButton sol = new KeyboardButton();
                sol.setText("C++");
                KeyboardButton aso = new KeyboardButton();
                aso.setText("Java");


                row1.add(eng);
                row2.add(sol);
                row3.add(aso);


                rowList.add(row1);
                rowList.add(row2);
                rowList.add(row3);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("какой курс вы выберете");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
            else if (update.getMessage().getText().equals("Telegram-бот")) {
                ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
                List<KeyboardRow> rowList = new ArrayList<>();
                KeyboardRow row1 = new KeyboardRow();
                KeyboardRow row2 = new KeyboardRow();
                KeyboardButton eng = new KeyboardButton();
                eng.setText("Создать бота в Telegram)");
                KeyboardButton zr = new KeyboardButton();
                zr.setText("Создать бота в Telegram на Phyton");


                row1.add(eng);
                row2.add(zr);


                rowList.add(row1);
                rowList.add(row2);
                markup.setKeyboard(rowList);
                markup.setResizeKeyboard(true);
                SendMessage message = new SendMessage();
                message.setText("какой курс вы выберете");
                message.setChatId(chatId);
                message.setReplyMarkup(markup);
                try {
                    execute(message);
                } catch (TelegramApiException e) {
                    throw new RuntimeException(e);
                }

            }
        }
        else if (update.getMessage().hasContact()) {
            ReplyKeyboardMarkup markup = new ReplyKeyboardMarkup();
            List<KeyboardRow> rowList = new ArrayList<>();
            KeyboardRow row1 = new KeyboardRow();
            KeyboardRow row2 = new KeyboardRow();
            KeyboardButton uz = new KeyboardButton();
            uz.setText("\uD83C\uDDFA\uD83C\uDDFFUzbek tili");
            KeyboardButton ru = new KeyboardButton();
            ru.setText("\uD83C\uDDF7\uD83C\uDDFARus tili");


            row1.add(uz);
            row2.add(ru);


            rowList.add(row1);
            rowList.add(row2);
            markup.setKeyboard(rowList);
            markup.setResizeKeyboard(true);
            SendMessage message = new SendMessage();
            message.setText("\uD83C\uDDFA\uD83C\uDDFF Tilni tanlang\n" +
                    "\uD83C\uDDF7\uD83C\uDDFA Выберите язык");
            message.setChatId(chatId);
            message.setReplyMarkup(markup);
            try {
                execute(message);
            } catch (TelegramApiException e) {
                throw new RuntimeException(e);
            }
        }
        else if (update.hasCallbackQuery()) {
        }
    }

    @Override
    public String getBotUsername() {
        return "PDP_Telegram_bot";
    }
}
