package org.example.modul.enums;

public enum Role {
    ADMIN,
    USER
}
