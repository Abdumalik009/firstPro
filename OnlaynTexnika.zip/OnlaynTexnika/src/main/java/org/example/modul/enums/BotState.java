package org.example.modul.enums;

public enum BotState {
    Menu,
    Design_Lessons,
    Program_Lessons,
    SMM_Lessons,
    Freelancer_Lessons,
    Accounting_Lessons,
    CopyWriting,
    English_Lessons,
    Office_Lessons,
    About_Us,
    Statistics,
    Contact_us,
}
