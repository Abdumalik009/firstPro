package org.example.model;

import lombok.*;
import org.example.modul.enums.BotState;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private long chatId;
    private String fullName;
    private String username;
    private String phoneNumber;
    private double longitude;
    private double latitude;
    private BotState state;

    public User(long chatId, String fullName, String username, BotState state) {
        this.chatId = chatId;
        this.fullName = fullName;
        this.username = username;
        this.state = state;
    }
}
